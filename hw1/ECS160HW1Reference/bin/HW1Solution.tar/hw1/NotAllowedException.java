package hw1;

public class NotAllowedException extends Exception {
	private static final long serialVersionUID = 8043957391935983504L;

	public NotAllowedException(String message)
	{
		super(message);
	}
}
