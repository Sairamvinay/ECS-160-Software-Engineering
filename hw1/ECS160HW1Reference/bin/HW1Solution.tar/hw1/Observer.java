package hw1;

public interface Observer {
	public void Update(Subject o);

}
