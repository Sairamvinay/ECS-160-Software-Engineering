package classes;

public interface Herbivore {
	
	public void consumePlant();

}
