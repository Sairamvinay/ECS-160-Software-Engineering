The file directory should be easy to understand. 

The students are supposed to create log files in the root directory, same as the example outputs.

Since Question 3 reuses many methods in Question 2, and I can't find a way to separate log files, so what I did so far 
is to append messages required in Question 3 to the log file created in Question 2. The log file is called "Q2&3Log.txt".

Please run the JUnit to see if no bug is found. It runs error-free on my laptop. Thanks!